%% Check Ray Paths
% Compare ray paths and travel-times from TauP and the Julia ray tracer
close all;
clear;
clc;

% Need to define full path to TauP jar-file to run code
TAUPJAR = strsplit(pwd,'/m-files');
TAUPJAR = [TAUPJAR{1},'/TauP-2.4.5/lib/TauP-2.4.5.jar'];
setenv('TAUPJAR',TAUPJAR);

% Input
RayFile = '../RayFiles/vp_2degs_60rad_20km_spacing_NewVersion.mat'; % Name of output mat-file with ray paths from Julia code
aModel = 'ak135'; % 1D Reference Earth model name recognizable by TauP (e.g. 'iasp91, 'ak135', 'prem')
aPhase = 'P'; % Seismic phase we are modelling ('P' or 'S' will give all direct/first arrivals)
sdepth = 0; % Source depth
Re     = 6371; % Earth radius
rg     = (0:1:6371)'; % Radial coordinate for linearly interpolated velocity model
dLq    = 10; % Re-integrat ray paths that have been re-discritized at this interval (km)
tf_vel = true; % Use average velocity for travel-time calculations (if false, use average slowness)

%% Compute rays and travel-times
% Load ray file and get list of paths
load(RayFile);
paths = whos('x_path*');

% Get interpolated and exact (i.e. discontinuous) TauP models
vp = get_TauP_model(rg,aModel);
[v1D,~,~,~,~,r1D] = get_TauP_model([],aModel);
% Use radius not depth for velocity model coordinate
r1D = Re - r1D;

H = figure; hold on;
DLT   = zeros(length(paths),1); % Range
ttp   = zeros(length(paths),1); % TauP Time
tsp   = zeros(length(paths),1); % Shortest path time
tsp1  = zeros(length(paths),1); % Linear re-integrated shortest path
tsp2  = zeros(length(paths),1); % Linear re-integrated fine shortest path
ttpi  = zeros(length(paths),1); % Piece-wise re-integrated TauP path
tsp1i = zeros(length(paths),1); % Piece-wise re-integrated shortest path
tsp2i = zeros(length(paths),1); % Piece-wise re-integrated fine shortest path
for ii = 1:length(paths)
    % Cartesian shortest path ray
    xi = eval(['x_path',num2str(ii)]);
    zi = eval(['z_path',num2str(ii)]);
    ti = eval(['travel_time_path',num2str(ii)]);
    % Polar shortest path ray
    theta   = atan2d(xi,zi);
    DLT(ii) = (theta(1) - theta(end));
    ri      = sqrt((xi.^2) + (zi.^2));
    % Fix rounding errors
    ri(ri > Re) = Re;
    ri(ri < 0)  = 0;
    % Distance along ray
    dLi = sqrt((diff(xi).^2) + (diff(zi).^2));
    Li  = cat(1,0,cumsum(dLi));
    
    % Fine ray path
    Lq   = linspace(Li(1),Li(end),1 + round((Li(end)-Li(1)))/dLq);
    xif  = interp1(Li,xi,Lq);
    zif  = interp1(Li,zi,Lq);
    dLif = sqrt((diff(xif).^2) + (diff(zif).^2));
    rif  = sqrt((xif.^2) + (zif.^2));
    rif(rif > Re) = Re;
    rif(rif < 0)  = 0;

    % TauP ray
    [latray,lonray,rray,ttray] = taup_path(aModel,aPhase,0,theta(end),sdepth,0,theta(1));
    rray = Re + rray;
    xray = rray.*sind(lonray);
    zray = rray.*cosd(lonray);
    % Distance along ray
    dL   = sqrt((diff(xray).^2) + (diff(zray).^2));
    Lray = cat(1,0,cumsum(dL));
    
    % Interpolate velocities
    vi   = interp1(Re-rg,vp,ri);
    vif  = interp1(Re-rg,vp,rif);
    vray = interp1(Re-rg,vp,rray);
    
    % Store travel-times
    % True values
    ttp(ii)  = ttray(end); % True TauP time
    tsp(ii)  = ti(1); % Shortest path code time
    % Linearly re-integrated shortest path times
    tsp1(ii)  = sum(dLi./((vi(1:end-1) + vi(2:end))./2));
    tsp2(ii)  = sum(dLif./((vif(1:end-1) + vif(2:end))./2));
    % Piece-wise re-integrated shortest path times
    ttpi(ii)  = tt_reintegrate1D(xray,zray,r1D,v1D,tf_vel);
    tsp1i(ii) = tt_reintegrate1D(xi,zi,r1D,v1D,tf_vel);
    tsp2i(ii) = tt_reintegrate1D(xif,zif,r1D,v1D,tf_vel);
    
    % Recompute travel-times along shortest path ray to check that my
    % re-integration gives the same as the Julia code.
    t1i  = flipud(cat(1,0,cumsum(dLi./((vi(1:end-1) + vi(2:end))./2))));
    vseg = dLi./abs(diff(ti));
    
    % Plot TauP and shortest path rays
    figure(H);
    plot(xray,zray,'-k','linewidth',2);
    plot(xi,zi,'-r','linewidth',1);
%     plot(xrayf,zrayf,'.k','linewidth',10);
%     plot(xif,zif,'.r','linewidth',10);
end
% Residuals
dtt   = ttp - tsp;
dtt0  = ttp - ttpi;
dtt1  = ttp - tsp1;
dtt2  = ttp - tsp2;
dtt1i = ttp - tsp1i;
dtt2i = ttp - tsp2i;

% Add Earth Layers
xs = sind(linspace(0,360,361));
zs = cosd(linspace(0,360,361));
% Earth surface
plot(Re*xs,Re*zs,'-k','linewidth',2);
% Upper crust
plot((Re-20)*xs,(Re-20)*zs,'--g','linewidth',1);
% Lower crust
plot((Re-35)*xs,(Re-35)*zs,'--g','linewidth',1);
% The 210
plot((Re-210)*xs,(Re-210)*zs,'--g','linewidth',1);
% The 410 km
plot((Re-410)*xs,(Re-410)*zs,'--g','linewidth',1);
% The 660 km
plot((Re-660)*xs,(Re-660)*zs,'--g','linewidth',1);
% Outer Core
plot((Re-2740)*xs,(Re-2740)*zs,'--g','linewidth',1);
plot((Re-2891.5)*xs,(Re-2891.5)*zs,'--g','linewidth',1);
% Inner Core
plot((Re-5153)*xs,(Re-5153)*zs,'--g','linewidth',1);
% Tick marks
xt = Re*sind(0:10:360);
zt = Re*cosd(0:10:360);
plot(xt,zt,'.m','markersize',30);
% Ray tracing grid
% plot(x,z,'.k','markersize',2);
axis image; box on; grid on;
xlim([-6371,6371]); ylim([-6371,6371]);

% Plot Errors
DLT = abs(DLT);
figure; hold on;
plot(DLT,dtt,'.k','markersize',10); % Shortest path error
plot(DLT,dtt1,'.b','markersize',10); % Linear reintegrated shortest path error
plot(DLT,dtt2,'.r','markersize',10); % Linear reintegrated fine shortest path error
plot(DLT,dtt0,'ok','markersize',5); % Piece-wise reintegrated TauP path error
plot(DLT,dtt1i,'ob','markersize',5); % Piece-wise reintegrated shortest path error
plot(DLT,dtt2i,'or','markersize',5); % Piece-wise reintegrated fine shortest path error
axis square; box on; grid on;
xlabel('range (deg.)'); ylabel('dt (s)');
legend('TauP - SP','TauP - SPLI','TauP - SPLIF','TauP - TauPPI','TauP - SPPI','TauP - SPPIF');

% Table of errors
MODEL = {'TauP - SP'; 'TauP - SPLI'; 'TauP - SPLIfine'; 'TauP - SPPW'; 'TauP - SPPWfine'};
MEAN = mean([dtt(:)';dtt1(:)';dtt2(:)';dtt1i(:)';dtt2i(:)'],2);
STD  = std([dtt(:)';dtt1(:)';dtt2(:)';dtt1i(:)';dtt2i(:)'],0,2);
MAX  = max(abs([dtt(:)';dtt1(:)';dtt2(:)';dtt1i(:)';dtt2i(:)']),[],2);
T    = table(MODEL,MEAN,STD,MAX);
disp(T);

% %% Why can I not reproduce the shortest path time???
% figure; hold on;
% plot(Li,ti,'-k','linewidth',2);
% plot(Li,t1i,'-r','linewidth',1);
% box on; grid on;
% xlabel('along-ray distance');
% ylabel('time (s)');
% 
% figure; hold on;
% plot(Li(1:end-1) + (dLi./2),vseg - ((vi(1:end-1) + vi(2:end))./2),'-k','linewidth',2);
% box on; grid on;
% xlabel('along-ray distance');
% ylabel('v (km/s)');