function [tt,L] = tt_reintegrate1D(xray,zray,r1D,v1D,tf_vel)
% TT_REINTEGRATE1D: Integrates travel-time along a ray path accounting for
% discontinuities in the velocity model. Gives same results as TauP.

% H = figure; hold on;
% plot(xray,zray,'-k','linewidth',1);
% axis image; box on; grid on; axis tight;

% Location of discontinuities in velocity model
rd = r1D(abs(diff(r1D)) == 0);

% Derive ray path radial coordinate
rray = sqrt((xray.^2) + (zray.^2));

% Integrate travel-time along path
nray = length(xray);
nv   = length(r1D);
tt   = 0;
L    = 0;
for kk = 1:(nray - 1)
    % Segment variables
    x1 = xray(kk);
    z1 = zray(kk);
    r1 = rray(kk);
    x2 = xray(kk+1);
    z2 = zray(kk+1);
    r2 = rray(kk+1);
    dL = sqrt(((x2 - x1)^2) + ((z2 - z1)^2));
    
    % Round radius to nearest meter
    r1 = round(1000*r1)/1000;
    r2 = round(1000*r2)/1000;
    
    
    % Get velocity model nodes between segment ends
    if r2 > r1
        % Up-going leg
        iv = find((r1D > r1) & (r1D < r2));
        if isempty(iv)
            iv = [find(r1D >= r2,1,'last'); find(r1D <= r1,1,'first')];
            rseg = [r1;r2];
            lseg = [0;dL];
        else
            iv   = (max(iv(1)-1,1):min(iv(end)+1,nv))';
            iv   = flipud(iv);
            rseg = [r1;r1D(iv(2:end-1));r2];
            lseg = interp1([r1;r2],[0;dL],rseg,'linear');
        end
        v1   = interp1(r1D(iv(1:2)),v1D(iv(1:2)),rseg(1),'linear');
        v2   = interp1(r1D(iv(end-1:end)),v1D(iv(end-1:end)),rseg(end),'linear');
        vseg = [v1;v1D(iv(2:end-1));v2];
    elseif r1 > r2
        % Down-going leg
        iv = find((r1D > r2) & (r1D < r1));
        if isempty(iv)
            iv   = [find(r1D <= r2,1,'first'); find(r1D >= r1,1,'last')];
            rseg = [r1;r2];
            lseg = [0;dL];
        else
            iv   = (max(iv(1)-1,1):min(iv(end)+1,nv))';
            rseg = [r1;r1D(iv(2:end-1));r2];
            lseg = interp1([r1;r2],[0,dL],rseg,'linear');
        end
        v1   = interp1(r1D(iv(1:2)),v1D(iv(1:2)),rseg(1),'linear');
        v2   = interp1(r1D(iv(end-1:end)),v1D(iv(end-1:end)),rseg(end),'linear');
        vseg = [v1;v1D(iv(2:end-1));v2];
    else
        % Horizontal leg
        iv = find(r1D == r1);
        % Consider this leg to be a critical diffraction along interface if
        % it occurs at a known discontinuity. In this case, the segment
        % length is adjusted for the curvature of the interface. It is
        % possible to imagine situations where this assumption is not
        % valid...
        if any(r1 == rd)
            dtheta = abs(atan2(x2,z2) - atan2(x1,z1));
            dL     = dtheta*r1;
        end
        if isempty(iv)
            iv   = [find(r1D <= r1,1,'first'); find(r1D >= r1,1,'last')];
            rseg = [r1;r2];
            lseg = [0;dL];
            vseg = interp1(r1D(iv),v1D(iv),rseg,'linear');
        else
            iv   = iv(v1D(iv) == max(v1D(iv)));
            iv   = [iv(1);iv(1)];
            vseg = v1D(iv);
            lseg = [0;dL];
        end
    end
    
    % Re-integrate segment times
    if tf_vel
        % Velocity averaging
        vseg = (vseg(1:end-1) + vseg(2:end))./2;
        dt   = sum(diff(lseg)./vseg);
    else
        % Slowness averaging
        vseg = 1./vseg;
        vseg = (vseg(1:end-1) + vseg(2:end))./2;
        dt   = sum(diff(lseg).*vseg);
    end
    
    % Update travel-time
    tt = tt + dt;
    L  = L + dL;
    
%     % Plot
%     xseg = interp1([0;dL],[x1;x2],lseg,'linear');
%     zseg = interp1([0;dL],[z1;z2],lseg,'linear');
%     xc   = xseg(1:end-1) + (diff(xseg)./2);
%     zc   = zseg(1:end-1) + (diff(zseg)./2);
%     figure(H);
%     plot(zc,vseg,'.r','markersize',10);
%     plot([x1,x2],[z1,z2],'.k','markersize',20);
%     scatter(xc,zc,25,vseg,'filled');
%     plot(xseg(2:end-1),zseg(2:end-1),'*k','markersize',10);
%     colorbar; colormap(jet);
%     %xlim([min(x1,x2),max(x1,x2)] + [-10,10]);
%     %ylim([min(z1,z2),max(z1,z2)]  + [-10,10]);
%     % keyboard
end
